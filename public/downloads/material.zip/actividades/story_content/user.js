function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5d2ewRUtXTJ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

